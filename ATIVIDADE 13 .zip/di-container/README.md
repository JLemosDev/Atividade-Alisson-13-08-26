# Container de Injeção de Dependências (DI) Simplificado

Implementação de um pequeno container de Injeção de Dependências em Java puro
(sem bibliotecas externas), usando apenas **Reflection** da própria linguagem.

## Estrutura do projeto

```
di-container/
├── README.md
└── src/
    ├── di/
    │   ├── Inject.java                     -> anotação @Inject
    │   ├── DIContainer.java                -> o container em si
    │   └── DependencyNotFoundException.java -> exceção para dependências não resolvidas
    └── di/example/
        ├── PaymentGateway.java / CreditCardPaymentGateway.java
        ├── MessageService.java / EmailMessageService.java
        ├── OrderService.java        -> injeção via CONSTRUTOR
        ├── NotificationService.java -> injeção via ATRIBUTO
        └── Main.java                -> demonstração de uso
```

## Como rodar

```bash
cd di-container
javac -d out $(find src -name "*.java")
java -cp out di.example.Main
```

## Requisitos atendidos

- **Dependências entre múltiplas classes**: `OrderService` depende de
  `PaymentGateway` e `MessageService` ao mesmo tempo; o container resolve
  cada uma recursivamente (inclusive dependências de dependências).
- **Reflection para localizar atributos anotados**: `DIContainer.injectFields`
  percorre `getDeclaredFields()` (subindo pela hierarquia de superclasses)
  procurando campos anotados com `@Inject`.
- **Resolução de construtores**: `DIContainer.instantiate` procura primeiro um
  construtor anotado com `@Inject`; na ausência dele, tenta o construtor
  padrão (sem argumentos) e, por fim, usa o primeiro construtor disponível.
  Os parâmetros do construtor escolhido são resolvidos recursivamente.
- **Tratamento de dependências não encontradas**: se um tipo solicitado for
  uma interface/classe abstrata sem `bind()` correspondente, ou se não houver
  construtor utilizável, ou se for detectada uma dependência circular, o
  container lança `DependencyNotFoundException` com uma mensagem explicativa.

## Relação com IoC / Dependency Injection (e frameworks como o Spring)

**Inversão de Controle (IoC)** é o princípio de que o *controle sobre a
criação e o ciclo de vida dos objetos* deixa de pertencer à própria classe
(que tradicionalmente faria `new` nas suas dependências) e passa a ser
responsabilidade de um agente externo — no nosso caso, o `DIContainer`.
A classe apenas declara *o que* precisa (via `@Inject` no construtor ou no
atributo) e não *como* obter essa dependência nem *quem* a implementa.

**Injeção de Dependências (DI)** é a técnica concreta usada para realizar essa
inversão: em vez de a classe buscar ativamente suas dependências, elas são
"empurradas" para dentro dela — por construtor, por atributo ou por setter.

Essa implementação segue exatamente essa lógica em miniatura:

| Neste projeto | No Spring |
|---|---|
| `@Inject` | `@Autowired` (ou o padrão `@Inject` do próprio JSR-330, que o Spring também suporta) |
| `container.bind(Interface, Impl)` | Registro de beans via `@Component`/`@Service` + `@Qualifier`, ou configuração explícita em classes `@Configuration` com métodos `@Bean` |
| `Map<Class<?>, Object> instances` (cache de singletons) | O **ApplicationContext**, que por padrão gerencia beans como singletons |
| `resolve(Class<T>)` percorrendo construtores/atributos via Reflection | O mecanismo interno do Spring (`BeanFactory`), que também usa Reflection extensivamente para inspecionar construtores, atributos e métodos anotados |
| `DependencyNotFoundException` | `NoSuchBeanDefinitionException` / `UnsatisfiedDependencyException` |
| Detecção de dependência circular via `resolutionStack` | Spring também detecta e lança `BeanCurrentlyInCreationException` em casos de referência circular não resolvível |

A diferença principal é de **escala e recursos**: o Spring adiciona ciclo de
vida completo de beans (escopos como *singleton*, *prototype*, *request*),
proxies dinâmicos para AOP, injeção via arquivos de configuração XML/Java,
resolução por nome/qualificador quando há múltiplas implementações da mesma
interface, integração com o container de anotações JSR-330/CDI, e muito mais
tooling em torno da IoC. Mas o núcleo conceitual — inspecionar a classe via
Reflection, descobrir do que ela precisa, resolver recursivamente e injetar —
é exatamente o que este pequeno container faz.
