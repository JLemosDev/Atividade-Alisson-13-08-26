package di.example;

public class EmailMessageService implements MessageService {
    @Override
    public void send(String message) {
        System.out.println("E-mail enviado: " + message);
    }
}
