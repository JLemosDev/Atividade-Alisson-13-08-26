package di.example;

import di.Inject;

/**
 * Demonstra injeção via CONSTRUTOR e dependências entre múltiplas classes:
 * OrderService depende de PaymentGateway e MessageService.
 */
public class OrderService {

    private final PaymentGateway paymentGateway;
    private final MessageService messageService;

    @Inject
    public OrderService(PaymentGateway paymentGateway, MessageService messageService) {
        this.paymentGateway = paymentGateway;
        this.messageService = messageService;
    }

    public void checkout(double amount) {
        paymentGateway.pay(amount);
        messageService.send("Pedido de R$" + amount + " confirmado.");
    }
}
