package di.example;

import di.DIContainer;

public class Main {

    // Interface propositalmente não vinculada, para demonstrar o
    // tratamento de dependência não encontrada.
    interface UnregisteredService {
    }

    public static void main(String[] args) {
        DIContainer container = new DIContainer();

        // 1. Vincula as interfaces às implementações concretas.
        container.bind(PaymentGateway.class, CreditCardPaymentGateway.class);
        container.bind(MessageService.class, EmailMessageService.class);

        // 2. Resolve OrderService: o container inspeciona o construtor via
        //    Reflection, percebe que precisa de PaymentGateway e MessageService,
        //    resolve cada dependência recursivamente e injeta automaticamente.
        OrderService orderService = container.resolve(OrderService.class);
        orderService.checkout(150.0);

        System.out.println("---");

        // 3. Resolve NotificationService: injeção via atributo anotado com @Inject.
        NotificationService notificationService = container.resolve(NotificationService.class);
        notificationService.notifyUser("Seu pedido está a caminho!");

        System.out.println("---");

        // 4. Dependência não encontrada: o container lança uma exceção clara.
        try {
            container.resolve(UnregisteredService.class);
        } catch (RuntimeException e) {
            System.out.println("Erro esperado ao resolver dependência ausente: " + e.getMessage());
        }
    }
}
