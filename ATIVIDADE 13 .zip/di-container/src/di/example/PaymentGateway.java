package di.example;

public interface PaymentGateway {
    void pay(double amount);
}
