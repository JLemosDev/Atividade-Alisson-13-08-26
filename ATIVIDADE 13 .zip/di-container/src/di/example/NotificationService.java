package di.example;

import di.Inject;

/**
 * Demonstra injeção via ATRIBUTO: o container localiza o campo anotado
 * com @Inject por Reflection e preenche automaticamente.
 */
public class NotificationService {

    @Inject
    private MessageService messageService;

    public void notifyUser(String text) {
        messageService.send("[Notificação] " + text);
    }
}
