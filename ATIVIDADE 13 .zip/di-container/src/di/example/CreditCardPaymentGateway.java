package di.example;

public class CreditCardPaymentGateway implements PaymentGateway {
    @Override
    public void pay(double amount) {
        System.out.println("Pagamento de R$" + amount + " realizado via cartão de crédito.");
    }
}
