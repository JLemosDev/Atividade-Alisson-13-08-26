package di.example;

public interface MessageService {
    void send(String message);
}
