package di;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.HashMap;
import java.util.Map;

/**
 * Container simples de Injeção de Dependências (DI).
 *
 * Funcionamento geral:
 *  1. Interfaces podem ser vinculadas a implementações concretas com bind().
 *  2. Ao resolver um tipo com resolve(), o container:
 *       a) verifica se já existe uma instância (comportamento singleton);
 *       b) descobre a implementação concreta (via bind, ou a própria classe);
 *       c) escolhe um construtor (de preferência um anotado com @Inject) e
 *          resolve recursivamente cada parâmetro do construtor;
 *       d) instancia o objeto via Reflection;
 *       e) percorre os atributos da classe procurando @Inject e injeta as
 *          dependências correspondentes (injeção por atributo);
 *       f) guarda a instância para reaproveitar em resoluções futuras.
 *
 * Esse é o mesmo princípio de Inversão de Controle (IoC) usado por
 * frameworks como o Spring: veja o README.md para a explicação detalhada.
 */
public class DIContainer {

    /** Instâncias já criadas, indexadas pelo tipo solicitado (singleton). */
    private final Map<Class<?>, Object> instances = new HashMap<>();

    /** Vínculos entre interface/classe abstrata e implementação concreta. */
    private final Map<Class<?>, Class<?>> bindings = new HashMap<>();

    /** Pilha usada apenas para detectar dependências circulares durante a resolução. */
    private final Deque<Class<?>> resolutionStack = new ArrayDeque<>();

    /**
     * Vincula uma interface (ou classe abstrata) a uma implementação concreta.
     * Exemplo: container.bind(PaymentGateway.class, CreditCardPaymentGateway.class);
     */
    public <T> void bind(Class<T> type, Class<? extends T> implementation) {
        bindings.put(type, implementation);
    }

    /**
     * Registra manualmente uma instância pronta (útil para configurações,
     * valores externos ou mocks em testes).
     */
    public <T> void registerInstance(Class<T> type, T instance) {
        instances.put(type, instance);
    }

    /**
     * Resolve (obtém ou cria) uma instância do tipo solicitado, injetando
     * automaticamente todas as dependências necessárias, recursivamente.
     */
    @SuppressWarnings("unchecked")
    public <T> T resolve(Class<T> type) {
        if (instances.containsKey(type)) {
            return (T) instances.get(type);
        }

        Class<?> implType = bindings.getOrDefault(type, type);

        if (implType.isInterface() || Modifier.isAbstract(implType.getModifiers())) {
            throw new DependencyNotFoundException(
                    "Nenhuma implementação vinculada para o tipo abstrato/interface '" + type.getName()
                            + "'. Use container.bind(" + type.getSimpleName()
                            + ".class, SuaImplementacao.class) antes de chamar resolve().");
        }

        if (resolutionStack.contains(implType)) {
            throw new DependencyNotFoundException(
                    "Dependência circular detectada envolvendo a classe: " + implType.getName());
        }

        resolutionStack.push(implType);
        try {
            Object instance = instantiate(implType);
            injectFields(instance);
            instances.put(type, instance);
            return (T) instance;
        } finally {
            resolutionStack.pop();
        }
    }

    /**
     * Escolhe o construtor a ser usado e resolve recursivamente cada parâmetro.
     * Ordem de preferência:
     *   1) construtor anotado com @Inject;
     *   2) construtor sem argumentos;
     *   3) primeiro construtor declarado disponível.
     */
    private Object instantiate(Class<?> implType) {
        Constructor<?> chosen = null;

        for (Constructor<?> constructor : implType.getDeclaredConstructors()) {
            if (constructor.isAnnotationPresent(Inject.class)) {
                chosen = constructor;
                break;
            }
        }

        if (chosen == null) {
            try {
                chosen = implType.getDeclaredConstructor();
            } catch (NoSuchMethodException noDefaultConstructor) {
                Constructor<?>[] all = implType.getDeclaredConstructors();
                if (all.length == 0) {
                    throw new DependencyNotFoundException(
                            "Nenhum construtor disponível para instanciar: " + implType.getName());
                }
                chosen = all[0];
            }
        }

        chosen.setAccessible(true);
        Class<?>[] paramTypes = chosen.getParameterTypes();
        Object[] args = new Object[paramTypes.length];
        for (int i = 0; i < paramTypes.length; i++) {
            args[i] = resolve(paramTypes[i]);
        }

        try {
            return chosen.newInstance(args);
        } catch (Exception e) {
            throw new DependencyNotFoundException(
                    "Falha ao instanciar '" + implType.getName() + "': " + e.getMessage());
        }
    }

    /**
     * Localiza, via Reflection, todos os atributos anotados com @Inject
     * (inclusive herdados de superclasses) e injeta as dependências resolvidas.
     */
    private void injectFields(Object instance) {
        Class<?> current = instance.getClass();
        while (current != null && current != Object.class) {
            for (Field field : current.getDeclaredFields()) {
                if (field.isAnnotationPresent(Inject.class)) {
                    field.setAccessible(true);
                    try {
                        if (field.get(instance) == null) {
                            Object dependency = resolve(field.getType());
                            field.set(instance, dependency);
                        }
                    } catch (IllegalAccessException e) {
                        throw new DependencyNotFoundException(
                                "Não foi possível injetar o campo '" + field.getName() + "' em "
                                        + current.getName() + ": " + e.getMessage());
                    }
                }
            }
            current = current.getSuperclass();
        }
    }
}
