package di;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Marca um construtor ou um atributo como ponto de injeção de dependência.
 *
 * - Em um construtor: indica ao container qual construtor deve ser usado
 *   para instanciar a classe (injeção via construtor).
 * - Em um atributo: indica que o container deve preencher aquele campo
 *   automaticamente após a instância ser criada (injeção via atributo).
 */
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.FIELD, ElementType.CONSTRUCTOR})
public @interface Inject {
}
