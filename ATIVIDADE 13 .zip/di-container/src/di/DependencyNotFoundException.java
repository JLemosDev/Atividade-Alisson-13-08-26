package di;

/**
 * Lançada quando o container não consegue resolver uma dependência:
 * seja porque nenhuma implementação foi vinculada a uma interface,
 * porque a classe não possui um construtor utilizável, ou porque
 * foi detectada uma dependência circular.
 */
public class DependencyNotFoundException extends RuntimeException {

    public DependencyNotFoundException(String message) {
        super(message);
    }

    public DependencyNotFoundException(Class<?> type) {
        super("Não foi possível resolver a dependência para o tipo: " + type.getName()
                + ". Verifique se a classe foi registrada/vinculada no container.");
    }
}
